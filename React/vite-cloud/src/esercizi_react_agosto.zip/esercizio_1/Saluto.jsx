import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

const Saluto = () => {
    return (
        <div className="container text-center mt-5">
            
            <h1 className="display-4 text-primary">
                BENVENUTO NEL MIO PRIMO COMPONENTE REACT!!!
            </h1>
        </div>
    );
};

export default Saluto;
