const piatti = [
  { id: 1, nome: 'Spaghetti alla Carbonara', prezzo: 12.5 },
  { id: 2, nome: 'Pizza Margherita', prezzo: 9.0 },
  { id: 3, nome: 'Lasagna al Forno', prezzo: 13.0 },
  { id: 4, nome: 'Risotto ai Funghi', prezzo: 11.5 },
  { id: 5, nome: 'Tagliata di Manzo', prezzo: 18.0 },
  { id: 6, nome: 'Melanzane alla Parmingiana', prezzo: 14.0 },
  { id: 7, nome: 'Insalata', prezzo: 6.0 },
];

export default piatti;
